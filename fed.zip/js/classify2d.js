// const R = require("./ramda.min.js");
// const math = require("./math.min.js");

// Make lists with null for federated workers
var data_federated = [[], [], [], [], []];
var num_clients = data_federated.length;
var labels_federated = fillArray(null, num_clients);
var num_points_federated = fillArray(null, num_clients);

// Plotting settings
var dotSize = 8.0;
var extent = 4;
var extent_posterior = 2;
var ss = 400 / (extent * 2); // scale for drawing
var ss_posterior = 400 / (extent_posterior * 2); // scale for drawing

var weight_vectors = fillArray(null, num_clients);
var weight_vector_mean = fillArray(null, num_clients);
var cov_matrices_client = fillArray(null, num_clients);
var gramm_matrices_client = fillArray(null, num_clients);

function myinit() {}

function random_data(fed_index) {
  var data = [];
  var labels = [];
  for (var k = 0; k < 40; k++) {
    data.push([convnetjs.randf(-3, 3), convnetjs.randf(-3, 3)]);
    labels.push(convnetjs.randf(0, 1) > 0.5 ? 1 : -1);
  }

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = labels.length;
}

function simple_data(fed_index) {
  var data = [];
  var labels = [];
  data.push([-0.4326, 1.1909]);
  labels.push(1);
  data.push([3.0, 3.0]);
  labels.push(1);
  data.push([0.1253, -0.0376]);
  labels.push(1);
  data.push([0.2877, 0.3273]);
  labels.push(1);
  data.push([-1.1465, 0.1746]);
  labels.push(1);
  data.push([1.8133, 1.0139]);
  labels.push(-1);
  data.push([2.7258, 1.0668]);
  labels.push(-1);
  data.push([1.4117, 0.5593]);
  labels.push(-1);
  data.push([3.1832, 0.3044]);
  labels.push(-1);
  data.push([1.8636, 0.1677]);
  labels.push(-1);
  data.push([0.5, 3.2]);
  labels.push(1);
  data.push([0.8, 3.2]);
  labels.push(1);
  data.push([1.0, -2.2]);
  labels.push(1);
  data.push([-0.5326, 1.209]);
  labels.push(1);
  data.push([2.8, 3.2]);
  labels.push(1);
  data.push([0.253, -0.376]);
  labels.push(1);
  data.push([0.4877, 0.1273]);
  labels.push(1);
  data.push([-1.465, 0.9746]);
  labels.push(1);
  data.push([1.533, 1.9139]);
  labels.push(-1);
  data.push([1.7258, 1.3668]);
  labels.push(-1);
  data.push([2.4117, -0.5593]);
  labels.push(-1);
  data.push([2.1832, -0.3044]);
  labels.push(-1);
  data.push([2.8636, 1.1677]);
  labels.push(-1);
  data.push([2.2, 2.2]);
  labels.push(1);
  data.push([1.8, 2.2]);
  labels.push(1);
  data.push([0.9, -3.2]);
  labels.push(1);

  data.push([2.8, -3.2]);
  labels.push(-1);
  data.push([2.4, -1.8]);
  labels.push(-1);
  data.push([3.5, -3.3]);
  labels.push(-1);

  data.push([-1.8, 2.3]);
  labels.push(1);
  data.push([-2.4, 1.9]);
  labels.push(1);
  data.push([-2.5, 1.8]);
  labels.push(1);

  data.push([-1.3, -1.2]);
  labels.push(1);
  data.push([-1.7, -2.3]);
  labels.push(1);
  data.push([-2.2, -2.5]);
  labels.push(1);

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = labels.length;
}

function simple_data2(fed_index) {
  var data = [];
  var labels = [];
  data.push([-1.4326, 1.1909]);
  labels.push(1);
  data.push([0.1253, -0.376]);
  labels.push(1);
  data.push([0.2877, 0.03273]);
  labels.push(1);
  data.push([-2.1465, 0.1746]);
  labels.push(1);
  data.push([2.3133, 1.0139]);
  labels.push(-1);
  data.push([2.7258, 1.668]);
  labels.push(-1);
  data.push([1.4117, 0.8893]);
  labels.push(-1);
  data.push([3.632, 0.3544]);
  labels.push(-1);
  data.push([1.2636, 0.8677]);
  labels.push(-1);
  data.push([0.9, 2.2]);
  labels.push(1);
  data.push([0.3, 2.2]);
  labels.push(1);
  data.push([2.0, -3.2]);
  labels.push(1);

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = labels.length;
}

function simple_data3(fed_index) {
  var data = [];
  var labels = [];
  data.push([-1.4326, 1.1909]);
  labels.push(1);
  data.push([3.0, 3.0]);
  labels.push(-1);
  data.push([1.1253, -0.376]);
  labels.push(1);
  data.push([1.2877, 0.03273]);
  labels.push(1);
  data.push([-1.1465, 0.1746]);
  labels.push(1);
  data.push([1.3133, 1.0139]);
  labels.push(-1);
  data.push([1.7258, 1.668]);
  labels.push(-1);
  data.push([2.1117, 0.8893]);
  labels.push(-1);
  data.push([2.632, 1.3544]);
  labels.push(-1);
  data.push([2.2636, -1.8677]);
  labels.push(-1);
  data.push([0.9, 2.8]);
  labels.push(1);
  data.push([0.3, 3.2]);
  labels.push(1);
  data.push([2.0, -0.2]);
  labels.push(1);

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = labels.length;
}

function simple_data4(fed_index) {
  var data = [];
  var labels = [];
  data.push([2.2, -2.3]);
  labels.push(-1);
  data.push([3.2, -1.8]);
  labels.push(-1);
  data.push([3, -2.5]);
  labels.push(-1);
  data.push([0.5, 2.1]);
  labels.push(1);
  data.push([0.1, 1.5]);
  labels.push(1);

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = labels.length;
}

function simple_data5(fed_index) {
  var data = [];
  var labels = [];
  data.push([2.4, -2.1]);
  labels.push(-1);
  data.push([2.8, -1.6]);
  labels.push(-1);
  data.push([0.4, 2.0]);
  labels.push(1);

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = labels.length;
}

function random_data_offset(fed_index, offsetx, offsety, spreadx) {
  var data = [];
  var labels = [];

  for (var k = 0; k < 40; k++) {
    data.push([
      offsetx + convnetjs.randf(-spreadx, spreadx),
      offsety + convnetjs.randf(-1, 1),
    ]);
    labels.push(convnetjs.randf(0, 1) > 0.5 ? 1 : -1);
  }
  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = labels.length;
}

function circle_data(fed_index) {
  var data = [];
  var labels = [];
  for (var i = 0; i < 50; i++) {
    var r = convnetjs.randf(0.0, 2.0);
    var t = convnetjs.randf(0.0, 2 * Math.PI);
    data.push([r * Math.sin(t), r * Math.cos(t)]);
    labels.push(1);
  }
  for (var i = 0; i < 50; i++) {
    var r = convnetjs.randf(3.0, 5.0);
    //var t = convnetjs.randf(0.0, 2*Math.PI);
    var t = (2 * Math.PI * i) / 50.0;
    data.push([r * Math.sin(t), r * Math.cos(t)]);
    labels.push(-1);
  }

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = data.length;
}

function spiral_data(fed_index) {
  var data = [];
  var labels = [];
  var n = 100;
  for (var i = 0; i < n; i++) {
    var r = (i / n) * 5 + convnetjs.randf(-0.1, 0.1);
    var t = ((1.25 * i) / n) * 2 * Math.PI + convnetjs.randf(-0.1, 0.1);
    data.push([r * Math.sin(t), r * Math.cos(t)]);
    labels.push(1);
  }
  for (var i = 0; i < n; i++) {
    var r = (i / n) * 5 + convnetjs.randf(-0.1, 0.1);
    var t =
      ((1.25 * i) / n) * 2 * Math.PI + Math.PI + convnetjs.randf(-0.1, 0.1);
    data.push([r * Math.sin(t), r * Math.cos(t)]);
    labels.push(-1);
  }

  // Put data and labels in federated objects
  data_federated[fed_index] = R.clone(data);
  labels_federated[fed_index] = R.clone(labels);
  num_points_federated[fed_index] = data.length;
}

function fillArray(value, len) {
  var arr = [];
  for (var i = 0; i < len; i++) {
    arr.push(R.clone(value));
  }
  return arr;
}

function RegressionInit() {
  weight_vectors = fillArray([1, 1, 1], num_clients);
}

function getCovAxes(cov_matrix) {
  result = math.eigs(cov_matrix);
  eigvalues = result.values;
  eigvectors = result.vectors;

  var cov_axis_0 = 2 * math.sqrt(eigvalues[0]) * ss_posterior;
  var cov_axis_1 = 2 * math.sqrt(eigvalues[1]) * ss_posterior;

  biggest = math.column(eigvectors, 1);
  var angle = math.atan(biggest[0] / biggest[1]);
  return [cov_axis_0, cov_axis_1, angle];
}

function invert_matrix(matrix_input) {
  var det =
    matrix_input[0][0] * matrix_input[1][1] -
    matrix_input[0][1] * matrix_input[1][0];
  determinant = Math.abs(det);

  var inverse = [
    [matrix_input[1][1] / det, -matrix_input[0][1] / det],
    [-matrix_input[1][0] / det, matrix_input[0][0] / det],
  ];
  return [inverse, determinant];
}

function invert_matrices(cov_matrices) {
  var inverses = [];
  var determinants = [];

  cov_matrices.forEach((cov_matrix) => {
    [inverse, det] = invert_matrix(cov_matrix);
    determinants.push(det);
    inverses.push(inverse);
  });
  return [determinants, inverses];
}

function multiplyAdd(x, A, b) {
  x[0] += A[0][0] * b[0] + A[0][1] * b[1] + A[0][2] * b[2];
  x[1] += A[1][0] * b[0] + A[1][1] * b[1] + A[1][2] * b[2];
  x[2] += A[2][0] * b[0] + A[2][1] * b[1] + A[2][2] * b[2];
  return x;
}

function FedRegressionUpdate() {
  num_points_total = 0;
  for (var fed_index = 0; fed_index < num_clients; fed_index++) {
    var num_points = num_points_federated[fed_index];
    num_points_total += num_points;

    data_tensor = tf.tensor2d(data_federated[fed_index]);
    label_tensor = tf.tensor2d(
      labels_federated[fed_index],
      (shape = [num_points, 1])
    );

    data_tensor = tf.concat(
      [data_tensor, tf.ones([num_points, 1])],
      (axis = 1)
    );

    var gram_matrix = tf.matMul(tf.transpose(data_tensor), data_tensor);
    gram_matrix = gram_matrix.arraySync();
    gramm_matrices_client[fed_index] = R.clone(gram_matrix);
    covariance_unscaled = tf.tensor2d(math.inv(gram_matrix));
    pseudo_inv = tf.matMul(covariance_unscaled, tf.transpose(data_tensor));
    weight_tensor = tf.matMul(pseudo_inv, label_tensor);

    // Store data
    weight_vectors[fed_index] = weight_tensor.dataSync();

    // Slice out first two coordinates for plotting
    cov_fetch = tf.slice(covariance_unscaled, [0, 0], [2, 2]).arraySync();
    cov_matrices_client[fed_index] = cov_fetch;
  }

  // Calculate posterior mean
  weight_vector_mean = [0, 0, 0];
  posterior_mean_unscaled = [0, 0, 0];
  for (var fed_index = 0; fed_index < num_clients; fed_index++) {
    weight_vector_mean[0] +=
      (weight_vectors[fed_index][0] * num_points_federated[fed_index]) /
      num_points_total;
    weight_vector_mean[1] +=
      (weight_vectors[fed_index][1] * num_points_federated[fed_index]) /
      num_points_total;
    weight_vector_mean[2] +=
      (weight_vectors[fed_index][2] * num_points_federated[fed_index]) /
      num_points_total;

    posterior_mean_unscaled = multiplyAdd(
      posterior_mean_unscaled,
      gramm_matrices_client[fed_index],
      weight_vectors[fed_index]
    );
  }

  // // Calculate posterior covariance
  var gramm_posterior = tf.eye(3);
  for (var fed_index = 0; fed_index < num_clients; fed_index++) {
    gramm_posterior = tf.add(
      gramm_posterior,
      tf.tensor2d(gramm_matrices_client[fed_index])
    );
  }
  covariance_posterior_server_full = math.inv(gramm_posterior.arraySync());
  covariance_posterior_server = [
    covariance_posterior_server_full[0].slice(0, 2),
    covariance_posterior_server_full[1].slice(0, 2),
  ];

  posterior_mean = multiplyAdd(
    [0, 0, 0],
    covariance_posterior_server_full,
    posterior_mean_unscaled
  );
}

function drawAxisValues(context, value) {
  var margin = 15;
  context.fillStyle = "rgb(0,0,0)";
  context.font = "15px sans-serif";
  context.fillText(-value, 0, HEIGHT / 2 + margin);
  context.fillText(value, WIDTH - margin, HEIGHT / 2 + margin);
  context.fillText(value, WIDTH / 2, 0 + margin);
  context.fillText(-value, WIDTH / 2, HEIGHT);
  context.fillText(0, WIDTH / 2 - margin, HEIGHT / 2 + margin);

  // draw axis lines
  context.beginPath();
  context.strokeStyle = "rgb(50,50,50)";
  context.lineWidth = 1;
  context.moveTo(0, HEIGHT / 2);
  context.lineTo(WIDTH, HEIGHT / 2);
  context.moveTo(WIDTH / 2, 0);
  context.lineTo(WIDTH / 2, HEIGHT);
  context.stroke();
}

function draw() {
  // Clear canvas
  contextsClients.forEach((context) => {
    context.clearRect(0, 0, WIDTH, HEIGHT);
  });
  // ctxServer.clearRect(0, 0, WIDTH, HEIGHT);

  // drawAxisValues(ctxServer, extent);

  contextsClients.forEach((context, fed_index) => {
    // Draw axis values
    drawAxisValues(context, extent);
  });

  // draw datapoints.
  contextsClients.forEach((context, fed_index) => {
    context.strokeStyle = "rgb(0,0,0)";
    context.lineWidth = 1;
    for (var i = 0; i < num_points_federated[fed_index]; i++) {
      if (labels_federated[fed_index][i] == 1) fillstyle = "rgb(100,200,100)";
      else fillstyle = "rgb(200,100,100)";
      // fillstyle = "rgb(200,100,100)";
      fillstyles = ["rgb(100,200,100)", "rgb(200,100,100)", "rgb(100,100,200)"];

      // Draw points for each of the clients
      drawCircle(
        context,
        WIDTH / 2 + data_federated[fed_index][i][0] * ss,
        HEIGHT / 2 - data_federated[fed_index][i][1] * ss,
        dotSize,
        fillstyle
      );

      // // Draw points for the first Posterior
      // drawCircle(
      //   ctxServer,
      //   WIDTH / 2 + data_federated[fed_index][i][0] * ss,
      //   HEIGHT / 2 - data_federated[fed_index][i][1] * ss,
      //   dotSize / 2,
      //   fillstyle
      // );
    }
  });
}

function drawLine(context, weight_vector, dashed) {
  dashed = typeof dashed !== "undefined" ? dashed : false;

  x_start = 0;
  y_start =
    HEIGHT / 2 +
    ((-extent * weight_vector[0] + weight_vector[2]) / weight_vector[1]) * ss;

  x_end = WIDTH;
  y_end =
    HEIGHT / 2 +
    ((extent * weight_vector[0] + weight_vector[2]) / weight_vector[1]) * ss;

  context.beginPath();
  context.strokeStyle = "rgb(50,50,250)";
  context.lineWidth = 3;
  if (dashed) {
    context.setLineDash([5, 15]);
  }
  context.moveTo(x_start, y_start);
  context.lineTo(x_end, y_end);
  context.stroke();
  context.setLineDash([]);
}

function choleskyDecomposition(matrix) {
  // Argument "matrix" can be either math.matrix or standard 2D array
  const A = math.matrix(matrix);
  // Matrix A must be symmetric
  console.assert(math.deepEqual(A, math.transpose(A)));

  const n = A.size()[0];
  // Prepare 2D array with 0
  const L = new Array(n).fill(0).map((_) => new Array(n).fill(0));

  math.range(0, n).forEach((i) => {
    math.range(0, i + 1).forEach((k) => {
      var s = 0;
      for (var j = 0; j < k; j++) {
        s += L[i][j] * L[k][j];
      }
      L[i][k] =
        i === k
          ? math.sqrt(A.get([k, k]) - s)
          : (1 / L[k][k]) * (A.get([i, k]) - s);
    });
  });
  return L;
}

function drawHeatMap() {
  const xrange = tf.linspace(-extent, extent, (num = 30));
  const [X_grid, Y_grid] = tf.meshgrid(xrange, xrange);
  data_grid = tf.stack(
    [tf.reshape(X_grid, [-1]), tf.reshape(Y_grid, [-1]), tf.ones([30 ** 2])],
    (axis = -1)
  );

  var test = choleskyDecomposition(covariance_posterior_server);
}

function drawRegressionLines() {
  weight_vectors.forEach((weight_vector, fed_index) => {
    drawLine(contextsClients[fed_index], weight_vector);
    drawLine(contextsClients[fed_index], weight_vector_mean, true);
  });
}

function drawGlobalWeightPosterior() {
  var context = ctxServerPosterior;
  // clear canvas
  context.clearRect(0, 0, WIDTH, HEIGHT);
  // Draw axis values
  drawAxisValues(context, extent_posterior);

  // Draw ellipse for posterior
  cov_matrix = covariance_posterior_server;

  [l_axis_0, l_axis_1, angle] = getCovAxes(cov_matrix);

  var mean_posterior_abs = [null, null];
  mean_posterior_abs[0] = posterior_mean[0] * ss_posterior + HEIGHT / 2;
  mean_posterior_abs[1] = HEIGHT / 2 - posterior_mean[1] * ss_posterior;

  context.beginPath();
  context.strokeStyle = "rgb(0,0,0)";
  context.ellipse(
    mean_posterior_abs[0],
    mean_posterior_abs[1],
    l_axis_1,
    l_axis_0,
    angle - Math.PI / 2,
    0,
    2 * Math.PI
  );
  context.stroke();
}

function drawLocalWeightPosterior() {
  contextsPosteriors.forEach((context, fed_index) => {
    // clear canvas
    context.clearRect(0, 0, WIDTH, HEIGHT);
    // Draw axis values
    drawAxisValues(context, extent_posterior);

    // Draw ellipse for posterior
    cov_matrix = cov_matrices_client[fed_index];

    [l_axis_0, l_axis_1, angle] = getCovAxes(cov_matrix);

    mean_posterior = weight_vectors[fed_index].slice(0, 2);

    var mean_posterior_abs = [null, null];
    mean_posterior_abs[0] = mean_posterior[0] * ss_posterior + HEIGHT / 2;
    mean_posterior_abs[1] = HEIGHT / 2 - mean_posterior[1] * ss_posterior;

    context.beginPath();
    context.strokeStyle = "rgb(0,0,0)";
    context.ellipse(
      mean_posterior_abs[0],
      mean_posterior_abs[1],
      l_axis_1,
      l_axis_0,
      angle - Math.PI / 2,
      0,
      2 * Math.PI
    );
    context.stroke();
  });
}

function mouseClick(fed_index, x, y, shiftPressed, ctrlPressed) {
  // x and y transformed to data space coordinates
  var xt = (x - WIDTH / 2) / ss;
  var yt = (HEIGHT / 2 - y) / ss;

  if (ctrlPressed) {
    // remove closest data point
    var index_min = -1;
    var dist_min = 99999;
    for (var k = 0, n = data_federated[fed_index].length; k < n; k++) {
      var dx = data_federated[fed_index][k][0] - xt;
      var dy = data_federated[fed_index][k][1] - yt;
      var d = dx * dx + dy * dy;
      if (d < dist_min || k == 0) {
        dist_min = d;
        index_min = k;
      }
    }
    if (index_min >= 0) {
      console.log("splicing " + index_min);
      data_federated[fed_index].splice(index_min, 1);
      labels_federated[fed_index].splice(index_min, 1);
      num_points_federated[fed_index] -= 1;
    }
  } else {
    // add datapoint at location of click
    data_federated[fed_index].push([xt, yt]);
    labels_federated[fed_index].push(shiftPressed ? 1 : -1);
    num_points_federated[fed_index] += 1;
  }
}

function keyDown(key) {}

function keyUp(key) {}

$(function () {
  // note, globals
  RegressionInit();

  simple_data(0);
  simple_data2(1);
  simple_data3(2);
  simple_data4(3);
  simple_data5(4);

  NPGinit(3);
});

module.exports = {
  invert_matrices: invert_matrices,
  choleskyDecomposition: choleskyDecomposition,
};
